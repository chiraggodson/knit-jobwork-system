import 'package:flutter/material.dart';
import '../services/api_service.dart';

class WasteEntryScreen extends StatefulWidget {
  final int jobId;

  const WasteEntryScreen({
    super.key,
    required this.jobId,
  });

  @override
  State<WasteEntryScreen> createState() => _WasteEntryScreenState();
}

class _WasteEntryScreenState extends State<WasteEntryScreen> {
  final TextEditingController _quantity = TextEditingController();
  bool loading = false;

  Future<void> submit() async {
    if (_quantity.text.isEmpty) return;

    setState(() => loading = true);

    try {
      await ApiService.addWaste(
        jobId: widget.jobId,
        quantity: double.parse(_quantity.text),
      );

      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(content: Text("Waste added successfully")),
        );
        Navigator.pop(context);
      }
    } catch (e) {
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text(e.toString())),
      );
    }

    setState(() => loading = false);
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text("Add Waste")),
      body: Padding(
        padding: const EdgeInsets.all(16),
        child: Column(
          children: [
            TextField(
              controller: _quantity,
              keyboardType: TextInputType.number,
              decoration: const InputDecoration(
                labelText: "Waste Quantity (kg)",
                border: OutlineInputBorder(),
              ),
            ),
            const SizedBox(height: 20),
            ElevatedButton(
              style: ElevatedButton.styleFrom(
                backgroundColor: Colors.red,
              ),
              onPressed: loading ? null : submit,
              child: loading
                  ? const CircularProgressIndicator(color: Colors.white)
                  : const Text("Add Waste"),
            ),
          ],
        ),
      ),
    );
  }
}
