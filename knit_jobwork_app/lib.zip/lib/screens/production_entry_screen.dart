import 'package:flutter/material.dart';
import '../services/api_service.dart';

class ProductionEntryScreen extends StatefulWidget {
  final int jobId;

  const ProductionEntryScreen({super.key, required this.jobId});

  @override
  State<ProductionEntryScreen> createState() => _ProductionEntryScreenState();
}

class _ProductionEntryScreenState extends State<ProductionEntryScreen> {
  final _formKey = GlobalKey<FormState>();

  final TextEditingController _rollNo = TextEditingController();
  final TextEditingController _quantity = TextEditingController();

  bool loading = false;

  Future<void> submit() async {
    if (!_formKey.currentState!.validate()) return;

    final qty = double.tryParse(_quantity.text);
    if (qty == null || qty <= 0) {
      ScaffoldMessenger.of(
        context,
      ).showSnackBar(const SnackBar(content: Text("Enter a valid quantity")));
      return;
    }

    setState(() => loading = true);

    try {
      await ApiService.addProduction(
        jobId: widget.jobId,
        rollNo: _rollNo.text.trim(),
        quantity: qty,
      );

      if (!mounted) return;

      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text("✅ Production added successfully")),
      );
      Navigator.pop(context);
    } catch (e) {
      ScaffoldMessenger.of(
        context,
      ).showSnackBar(SnackBar(content: Text("❌ ${e.toString()}")));
    } finally {
      if (mounted) {
        setState(() => loading = false);
      }
    }
  }

  @override
  void dispose() {
    _rollNo.dispose();
    _quantity.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text("Add Production")),
      body: Padding(
        padding: const EdgeInsets.all(16),
        child: Form(
          key: _formKey,
          child: Column(
            children: [
              // ROLL NO
              TextFormField(
                controller: _rollNo,
                decoration: const InputDecoration(
                  labelText: "Roll No",
                  border: OutlineInputBorder(),
                ),
                validator: (v) =>
                    v == null || v.trim().isEmpty ? "Roll No required" : null,
              ),
              const SizedBox(height: 16),

              // QUANTITY
              TextFormField(
                controller: _quantity,
                keyboardType: const TextInputType.numberWithOptions(
                  decimal: true,
                ),
                decoration: const InputDecoration(
                  labelText: "Quantity (kg)",
                  border: OutlineInputBorder(),
                ),
                validator: (v) =>
                    v == null || v.trim().isEmpty ? "Quantity required" : null,
              ),
              const SizedBox(height: 24),

              // SUBMIT
              SizedBox(
                width: double.infinity,
                height: 48,
                child: ElevatedButton(
                  onPressed: loading ? null : submit,
                  child: loading
                      ? const CircularProgressIndicator(color: Colors.white)
                      : const Text("Save Production"),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}
