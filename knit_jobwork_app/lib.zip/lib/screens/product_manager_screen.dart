import 'package:flutter/material.dart';
import '../services/api_service.dart';

class ProductManagerScreen extends StatefulWidget {
  const ProductManagerScreen({super.key});

  @override
  State<ProductManagerScreen> createState() => _ProductManagerScreenState();
}

class _ProductManagerScreenState extends State<ProductManagerScreen>
    with SingleTickerProviderStateMixin {
  late TabController _tabController;

  @override
  void initState() {
    super.initState();
    _tabController = TabController(length: 2, vsync: this);
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text("Product Manager"),
        bottom: TabBar(
          controller: _tabController,
          tabs: const [
            Tab(text: "Fabrics"),
            Tab(text: "Yarns"),
          ],
        ),
      ),
      body: TabBarView(
        controller: _tabController,
        children: const [
          ProductList(type: "FABRIC"),
          ProductList(type: "YARN"),
        ],
      ),
    );
  }
}

/* ================= PRODUCT LIST ================= */

class ProductList extends StatelessWidget {
  final String type;
  const ProductList({super.key, required this.type});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: FutureBuilder(
        future: type == "FABRIC"
            ? ApiService.getFabrics()
            : ApiService.getYarns(),
        builder: (context, snapshot) {
          if (!snapshot.hasData) {
            return const Center(child: CircularProgressIndicator());
          }

          final products = snapshot.data as List;

          if (products.isEmpty) {
            return const Center(child: Text("No products found"));
          }

          return ListView.builder(
            itemCount: products.length,
            itemBuilder: (context, index) {
              final p = products[index];
              return Card(
                margin: const EdgeInsets.all(8),
                child: ListTile(title: Text(p['name'])),
              );
            },
          );
        },
      ),

      // ➕ ADD PRODUCT
      floatingActionButton: FloatingActionButton(
        onPressed: () {
          Navigator.push(
            context,
            MaterialPageRoute(builder: (_) => AddProductScreen(type: type)),
          );
        },
        child: const Icon(Icons.add),
      ),
    );
  }
}

/* ================= ADD PRODUCT ================= */

class AddProductScreen extends StatefulWidget {
  final String type;
  const AddProductScreen({super.key, required this.type});

  @override
  State<AddProductScreen> createState() => _AddProductScreenState();
}

class _AddProductScreenState extends State<AddProductScreen> {
  final _name = TextEditingController();
  bool loading = false;

  void submit() async {
    if (_name.text.isEmpty) return;

    setState(() => loading = true);

    await ApiService.addProduct(name: _name.text.trim(), type: widget.type);

    if (mounted) Navigator.pop(context);
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text("Add ${widget.type}")),
      body: Padding(
        padding: const EdgeInsets.all(16),
        child: Column(
          children: [
            TextField(
              controller: _name,
              decoration: const InputDecoration(
                labelText: "Name",
                border: OutlineInputBorder(),
              ),
            ),
            const SizedBox(height: 20),
            ElevatedButton(
              onPressed: loading ? null : submit,
              child: loading
                  ? const CircularProgressIndicator()
                  : const Text("Save"),
            ),
          ],
        ),
      ),
    );
  }
}
