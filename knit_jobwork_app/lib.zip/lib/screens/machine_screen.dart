import 'package:flutter/material.dart';
import '../services/api_service.dart';

class MachineScreen extends StatelessWidget {
  const MachineScreen({super.key});

  Color _statusColor(String status) {
    switch (status) {
      case "RUNNING":
        return Colors.green;
      case "CLEANING":
        return Colors.orange;
      case "BREAKDOWN":
        return Colors.red;
      default:
        return Colors.grey;
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text("Machines")),

      body: FutureBuilder(
        future: ApiService.getMachines(),
        builder: (context, snapshot) {
          if (snapshot.connectionState == ConnectionState.waiting) {
            return const Center(child: CircularProgressIndicator());
          }

          if (snapshot.hasError) {
            return Center(child: Text(snapshot.error.toString()));
          }

          final machines = snapshot.data as List;

          return ListView.builder(
            itemCount: machines.length,
            itemBuilder: (context, index) {
              final m = machines[index];

              return Card(
                margin: const EdgeInsets.all(8),
                child: ListTile(
                  leading: CircleAvatar(
                    backgroundColor: _statusColor(m['status']),
                  ),
                  title: Text(
                    "Machine ${m['machine_no']}",
                    style: const TextStyle(fontWeight: FontWeight.bold),
                  ),
                  subtitle: Text(
                    "Status: ${m['status']}\n"
                    "Job: ${m['job_no'] ?? '—'}",
                  ),
                ),
              );
            },
          );
        },
      ),

      floatingActionButton: FloatingActionButton(
        tooltip: "Add Machine",
        child: const Icon(Icons.add),
        onPressed: () async {
          final controller = TextEditingController();

          await showDialog(
            context: context,
            builder: (_) => AlertDialog(
              title: const Text("Add Machine"),
              content: TextField(
                controller: controller,
                decoration: const InputDecoration(labelText: "Machine No"),
              ),
              actions: [
                TextButton(
                  onPressed: () => Navigator.pop(context),
                  child: const Text("Cancel"),
                ),
                ElevatedButton(
                  onPressed: () async {
                    await ApiService.createMachine(controller.text.trim());
                    Navigator.pop(context);
                  },
                  child: const Text("Save"),
                ),
              ],
            ),
          );
        },
      ),
    );
  }
}
