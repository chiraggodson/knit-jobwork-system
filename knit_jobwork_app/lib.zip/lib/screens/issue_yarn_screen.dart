import 'package:flutter/material.dart';
import '../services/api_service.dart';

class IssueYarnScreen extends StatefulWidget {
  final int jobId;

  const IssueYarnScreen({super.key, required this.jobId});

  @override
  State<IssueYarnScreen> createState() => _IssueYarnScreenState();
}

class _IssueYarnScreenState extends State<IssueYarnScreen> {
  final _quantity = TextEditingController();

  int yarnStockId = 1; // temporary (next: dropdown)
  bool loading = false;

  void submit() async {
    setState(() => loading = true);

    if (_quantity.text.isEmpty) {
      ScaffoldMessenger.of(
        context,
      ).showSnackBar(const SnackBar(content: Text("Enter quantity")));
      setState(() => loading = false);
      return;
    }

    try {
      await ApiService.issueYarn(
        jobId: widget.jobId, // ✅ REAL JOB ID
        yarnStockId: yarnStockId,
        quantity: double.parse(_quantity.text),
      );

      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(content: Text("Yarn issued successfully")),
        );
        Navigator.pop(context);
      }
    } catch (e) {
      ScaffoldMessenger.of(
        context,
      ).showSnackBar(SnackBar(content: Text(e.toString())));
    }

    setState(() => loading = false);
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text("Issue Yarn")),
      body: Padding(
        padding: const EdgeInsets.all(16),
        child: Column(
          children: [
            TextField(
              controller: _quantity,
              decoration: const InputDecoration(labelText: "Quantity (kg)"),
              keyboardType: TextInputType.number,
            ),
            const SizedBox(height: 20),
            ElevatedButton(
              onPressed: loading ? null : submit,
              child: loading
                  ? const CircularProgressIndicator()
                  : const Text("Issue Yarn"),
            ),
          ],
        ),
      ),
    );
  }
}
