import 'package:flutter/material.dart';

import '../theme/app_colors.dart';
import '../widgets/app_header.dart';
import '../widgets/kpi_card.dart';
import '../widgets/responsive_wrap.dart';
import '../widgets/machine_status_card_api.dart';

import '../models/user_model.dart';
import '../services/api_service.dart';

class DashboardScreen extends StatelessWidget {
  DashboardScreen({super.key});

  final UserModel currentUser =
      UserModel(name: "Chirag", role: "admin"); // change to 'user'

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: AppColors.background,
      body: Column(
        children: [
          AppHeader(
            title: "Dashboard",
            subtitle: "Production Overview",
            user: currentUser,
          ),

          Expanded(
            child: SingleChildScrollView(
              padding: const EdgeInsets.all(20),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [

                  // ================= KPI SECTION =================
                  ResponsiveWrap(
                    children: [
                      const KpiCard(
                        title: "Active Jobs",
                        value: "24",
                        subText: "+3 today",
                        accent: AppColors.green,
                      ),
                      const KpiCard(
                        title: "Machines Running",
                        value: "18 / 22",
                        subText: "82% active",
                        accent: AppColors.blue,
                      ),
                      const KpiCard(
                        title: "Today's Production",
                        value: "4,850 kg",
                        subText: "On track",
                        accent: AppColors.green,
                      ),
                      if (currentUser.isAdmin)
                        const KpiCard(
                          title: "Pending Orders",
                          value: "6",
                          subText: "Needs attention",
                          accent: AppColors.red,
                        ),
                    ],
                  ),

                  const SizedBox(height: 32),

                  // ================= MACHINE STATUS =================
                  Text(
                    "Machine Status",
                    style: TextStyle(
                      fontSize: 16,
                      fontWeight: FontWeight.w600,
                      color: AppColors.textPrimary,
                    ),
                  ),

                  const SizedBox(height: 16),

                  FutureBuilder(
                    future: ApiService.getMachines(),
                    builder: (context, snapshot) {
                      if (snapshot.connectionState ==
                          ConnectionState.waiting) {
                        return const Padding(
                          padding: EdgeInsets.all(24),
                          child: Center(child: CircularProgressIndicator()),
                        );
                      }

                      if (snapshot.hasError) {
                        return Text(
                          snapshot.error.toString(),
                          style: const TextStyle(color: Colors.red),
                        );
                      }

                      final machines = snapshot.data as List;

                      return ResponsiveWrap(
                        children: machines
                            .map(
                              (m) => MachineStatusCardApi(
                                machine: m,
                                isAdmin: currentUser.isAdmin,
                              ),
                            )
                            .toList(),
                      );
                    },
                  ),
                ],
              ),
            ),
          ),
        ],
      ),
    );
  }
}
