import 'package:flutter/material.dart';
import '../services/api_service.dart';
import 'issue_yarn_screen.dart';
import 'production_entry_screen.dart';
import 'yarn_return_screen.dart';
import 'waste_entry_screen.dart';

class JobDetailScreen extends StatelessWidget {
  final int jobId;
  final String jobNo;

  const JobDetailScreen({
    super.key,
    required this.jobId,
    required this.jobNo,
  });

  Color statusColor(String status) {
    switch (status) {
      case 'CLOSED':
        return Colors.red.shade100;
      case 'RUNNING':
        return Colors.green.shade100;
      default:
        return Colors.orange.shade100;
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text("Job $jobNo")),

      body: FutureBuilder<Map<String, dynamic>>(
        future: ApiService.getJobDetail(jobNo),
        builder: (context, snapshot) {
          if (snapshot.connectionState == ConnectionState.waiting) {
            return const Center(child: CircularProgressIndicator());
          }

          if (snapshot.hasError || !snapshot.hasData) {
            return const Center(child: Text("Failed to load job details"));
          }

          final job = snapshot.data!;

          final partyName = job['party_name'] ?? '-';
          final machineNo = job['machine_no']?.toString() ?? '-';
          final fabricType = job['fabric_type'] ?? '-';
          final gsm = job['gsm']?.toString() ?? '-';

          final double orderQty =
              double.tryParse(job['order_quantity']?.toString() ?? '0') ?? 0;
          final double yarnIssued =
              double.tryParse(job['yarn_issued']?.toString() ?? '0') ?? 0;
          final double fabricProduced =
              double.tryParse(job['fabric_produced']?.toString() ?? '0') ?? 0;
          final double yarnReturned =
              double.tryParse(job['yarn_returned']?.toString() ?? '0') ?? 0;
          final double waste =
              double.tryParse(job['waste']?.toString() ?? '0') ?? 0;

          final String status = job['status'] ?? 'OPEN';

          return ListView(
            padding: const EdgeInsets.all(16),
            children: [
              /// ===== JOB INFO CARD =====
              Card(
                elevation: 2,
                shape: RoundedRectangleBorder(
                  borderRadius: BorderRadius.circular(12),
                ),
                child: Padding(
                  padding: const EdgeInsets.all(16),
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(
                        partyName,
                        style: const TextStyle(
                          fontSize: 18,
                          fontWeight: FontWeight.bold,
                        ),
                      ),
                      const SizedBox(height: 12),
                      _info("Job No", jobNo),
                      _info("Machine", machineNo),
                      _info("Fabric", fabricType),
                      _info("GSM", gsm),
                      _info(
                        "Order Qty",
                        "${orderQty.toStringAsFixed(2)} kg",
                      ),
                      const SizedBox(height: 12),
                      Align(
                        alignment: Alignment.centerLeft,
                        child: Chip(
                          label: Text(status),
                          backgroundColor: statusColor(status),
                        ),
                      ),
                    ],
                  ),
                ),
              ),

              const SizedBox(height: 16),

              /// ===== STATS CARD =====
              Card(
                elevation: 2,
                shape: RoundedRectangleBorder(
                  borderRadius: BorderRadius.circular(12),
                ),
                child: Padding(
                  padding: const EdgeInsets.all(16),
                  child: Column(
                    children: [
                      _stat("Yarn Issued", yarnIssued),
                      _stat("Fabric Produced", fabricProduced),
                      _stat("Yarn Returned", yarnReturned),
                      _stat("Waste", waste),
                    ],
                  ),
                ),
              ),

              const SizedBox(height: 24),

              /// ===== ACTION BUTTONS =====
              _actionButton(
                context,
                icon: Icons.send,
                label: "Issue Yarn",
                onTap: () {
                  Navigator.push(
                    context,
                    MaterialPageRoute(
                      builder: (_) => IssueYarnScreen(jobId: jobId),
                    ),
                  );
                },
              ),

              _actionButton(
                context,
                icon: Icons.add_box,
                label: "Add Production",
                onTap: () {
                  Navigator.push(
                    context,
                    MaterialPageRoute(
                      builder: (_) => ProductionEntryScreen(jobId: jobId),
                    ),
                  );
                },
              ),

              _actionButton(
                context,
                icon: Icons.undo,
                label: "Yarn Return",
                onTap: () {
                  Navigator.push(
                    context,
                    MaterialPageRoute(
                      builder: (_) => YarnReturnScreen(
                        jobId: jobId,
                        partyId: job['party_id'],
                      ),
                    ),
                  );
                },
              ),

              _actionButton(
                context,
                icon: Icons.delete,
                label: "Add Waste",
                color: Colors.red,
                onTap: () {
                  Navigator.push(
                    context,
                    MaterialPageRoute(
                      builder: (_) => WasteEntryScreen(jobId: jobId),
                    ),
                  );
                },
              ),
            ],
          );
        },
      ),
    );
  }

  /// ===== SMALL HELPERS =====

  Widget _info(String label, String value) {
    return Padding(
      padding: const EdgeInsets.only(bottom: 6),
      child: Text("$label: $value"),
    );
  }

  Widget _stat(String label, double value) {
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 8),
      child: Row(
        mainAxisAlignment: MainAxisAlignment.spaceBetween,
        children: [
          Text(label),
          Text(
            "${value.toStringAsFixed(2)} kg",
            style: const TextStyle(fontWeight: FontWeight.bold),
          ),
        ],
      ),
    );
  }

  Widget _actionButton(
    BuildContext context, {
    required IconData icon,
    required String label,
    required VoidCallback onTap,
    Color color = Colors.blue,
  }) {
    return Padding(
      padding: const EdgeInsets.only(bottom: 12),
      child: SizedBox(
        width: double.infinity,
        height: 48,
        child: ElevatedButton.icon(
          icon: Icon(icon),
          label: Text(label),
          style: ElevatedButton.styleFrom(
            backgroundColor: color,
            shape: RoundedRectangleBorder(
              borderRadius: BorderRadius.circular(8),
            ),
          ),
          onPressed: onTap,
        ),
      ),
    );
  }
}
