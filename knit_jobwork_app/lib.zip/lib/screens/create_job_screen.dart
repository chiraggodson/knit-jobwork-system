import 'package:flutter/material.dart';
import '../services/api_service.dart';

class CreateJobScreen extends StatefulWidget {
  const CreateJobScreen({super.key});

  @override
  State<CreateJobScreen> createState() => _CreateJobScreenState();
}

class _CreateJobScreenState extends State<CreateJobScreen> {
  final _formKey = GlobalKey<FormState>();

  // Controllers
  final _gsm = TextEditingController();
  final _quantity = TextEditingController();

  // Party
  List parties = [];
  int? partyId;
  bool partyLoading = true;

  // Machine
  List machines = [];
  int? machineId;
  bool machineLoading = true;

  // Fabric
  final _fabricType = TextEditingController();

  bool loading = false;

  @override
  void initState() {
    super.initState();
    loadParties();
    loadMachines();
  }

  Future<void> loadParties() async {
    try {
      final data = await ApiService.getParties();
      setState(() {
        parties = data;
        partyLoading = false;
      });
    } catch (_) {
      partyLoading = false;
    }
  }

  Future<void> loadMachines() async {
    try {
      final data = await ApiService.getMachines();
      setState(() {
        machines = data;
        machineLoading = false;
      });
    } catch (_) {
      machineLoading = false;
    }
  }

  Future<void> submit() async {
    if (!_formKey.currentState!.validate()) return;

    if (partyId == null || machineId == null) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text("Party & Machine required")),
      );
      return;
    }

    setState(() => loading = true);

    try {
      await ApiService.createJob(
        partyId: partyId!,
        machineId: machineId!,
        fabricType: _fabricType.text.trim(),
        gsm: int.parse(_gsm.text),
        orderQuantity: double.parse(_quantity.text),
      );

      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(content: Text("Job created successfully")),
        );
        Navigator.pop(context);
      }
    } catch (e) {
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text(e.toString())),
      );
    }

    setState(() => loading = false);
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text("Create Job")),
      body: SingleChildScrollView(
        padding: const EdgeInsets.all(16),
        child: Form(
          key: _formKey,
          child: Column(
            children: [
              // PARTY
              partyLoading
                  ? const CircularProgressIndicator()
                  : DropdownButtonFormField<int>(
                      value: partyId,
                      decoration: const InputDecoration(
                        labelText: "Party",
                        border: OutlineInputBorder(),
                      ),
                      items: parties
                          .map<DropdownMenuItem<int>>(
                            (p) => DropdownMenuItem(
                              value: p['id'],
                              child: Text(p['name']),
                            ),
                          )
                          .toList(),
                      onChanged: (v) => setState(() => partyId = v),
                      validator: (v) => v == null ? "Required" : null,
                    ),
              const SizedBox(height: 16),

              // MACHINE 🔽
              machineLoading
                  ? const CircularProgressIndicator()
                  : DropdownButtonFormField<int>(
                      value: machineId,
                      decoration: const InputDecoration(
                        labelText: "Machine",
                        border: OutlineInputBorder(),
                      ),
                      items: machines
                          .map<DropdownMenuItem<int>>(
                            (m) => DropdownMenuItem(
                              value: m['id'],
                              child: Text("Machine ${m['machine_no']}"),
                            ),
                          )
                          .toList(),
                      onChanged: (v) => setState(() => machineId = v),
                      validator: (v) => v == null ? "Required" : null,
                    ),
              const SizedBox(height: 16),

              // FABRIC TYPE
              TextFormField(
                controller: _fabricType,
                decoration: const InputDecoration(
                  labelText: "Fabric Type",
                  border: OutlineInputBorder(),
                ),
                validator: (v) => v == null || v.isEmpty ? "Required" : null,
              ),
              const SizedBox(height: 16),

              // GSM
              TextFormField(
                controller: _gsm,
                keyboardType: TextInputType.number,
                decoration: const InputDecoration(
                  labelText: "GSM",
                  border: OutlineInputBorder(),
                ),
                validator: (v) => v == null || v.isEmpty ? "Required" : null,
              ),
              const SizedBox(height: 16),

              // ORDER QUANTITY
              TextFormField(
                controller: _quantity,
                keyboardType: TextInputType.number,
                decoration: const InputDecoration(
                  labelText: "Order Quantity (kg)",
                  border: OutlineInputBorder(),
                ),
                validator: (v) => v == null || v.isEmpty ? "Required" : null,
              ),
              const SizedBox(height: 24),

              SizedBox(
                width: double.infinity,
                height: 48,
                child: ElevatedButton(
                  onPressed: loading ? null : submit,
                  child: loading
                      ? const CircularProgressIndicator(color: Colors.white)
                      : const Text("Create Job"),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}
