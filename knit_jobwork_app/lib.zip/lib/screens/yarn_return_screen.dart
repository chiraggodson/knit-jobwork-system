import 'package:flutter/material.dart';

class YarnReturnScreen extends StatefulWidget {
  final int jobId;
  final int partyId;

  const YarnReturnScreen({
    super.key,
    required this.jobId,
    required this.partyId,
  });

  @override
  State<YarnReturnScreen> createState() => _YarnReturnScreenState();
}

class _YarnReturnScreenState extends State<YarnReturnScreen> {
  final _formKey = GlobalKey<FormState>();
  final TextEditingController _quantity = TextEditingController();
  final TextEditingController _remarks = TextEditingController();

  bool loading = false;

  void submit() {
    if (!_formKey.currentState!.validate()) return;

    setState(() => loading = true);

    // 🔴 BACKEND WILL BE CONNECTED LATER
    Future.delayed(const Duration(seconds: 1), () {
      if (!mounted) return;

      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text("Yarn returned successfully")),
      );

      Navigator.pop(context);
    });
  }

  @override
  void dispose() {
    _quantity.dispose();
    _remarks.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text("Yarn Return"),
      ),
      body: Padding(
        padding: const EdgeInsets.all(16),
        child: Form(
          key: _formKey,
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text(
                "Job ID: ${widget.jobId}",
                style: const TextStyle(fontWeight: FontWeight.bold),
              ),
              const SizedBox(height: 4),
              Text(
                "Party ID: ${widget.partyId}",
                style: const TextStyle(color: Colors.grey),
              ),

              const SizedBox(height: 20),

              /// RETURN QUANTITY
              TextFormField(
                controller: _quantity,
                keyboardType: TextInputType.number,
                decoration: const InputDecoration(
                  labelText: "Return Quantity (kg)",
                  border: OutlineInputBorder(),
                ),
                validator: (v) =>
                    v == null || v.isEmpty ? "Required" : null,
              ),

              const SizedBox(height: 16),

              /// REMARKS
              TextFormField(
                controller: _remarks,
                decoration: const InputDecoration(
                  labelText: "Remarks (optional)",
                  border: OutlineInputBorder(),
                ),
                maxLines: 2,
              ),

              const SizedBox(height: 24),

              /// SUBMIT
              SizedBox(
                width: double.infinity,
                height: 48,
                child: ElevatedButton(
                  onPressed: loading ? null : submit,
                  child: loading
                      ? const CircularProgressIndicator(color: Colors.white)
                      : const Text("Return Yarn"),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}
