import 'dart:convert';
import 'package:http/http.dart' as http;

class ApiService {
  static const String baseUrl = "http://192.168.29.189:4000/api";

  /* ================= JOBS ================= */

  static Future<List<dynamic>> getJobs() async {
    final res = await http.get(Uri.parse("$baseUrl/reports/jobs"));
    if (res.statusCode != 200) {
      throw Exception("Failed to load jobs");
    }
    return jsonDecode(res.body);
  }

  static Future<Map<String, dynamic>> getJobDetail(String jobNo) async {
    final res = await http.get(Uri.parse("$baseUrl/reports/job/$jobNo"));

    if (res.statusCode != 200) {
      throw Exception("Failed to load job detail");
    }

    return jsonDecode(res.body);
  }

  // ================= CREATE JOB =================
  static Future<void> createJob({
    required int partyId,
    required int machineId,
    required String fabricType,
    required int gsm,
    required double orderQuantity,
  }) async {
    final res = await http.post(
      Uri.parse("$baseUrl/jobs"),
      headers: {"Content-Type": "application/json"},
      body: jsonEncode({
        "party_id": partyId,
        "machine_id": machineId,
        "fabric_type": fabricType,
        "gsm": gsm,
        "order_quantity": orderQuantity,
      }),
    );

    if (res.statusCode != 200 && res.statusCode != 201) {
      throw Exception("Failed to create job");
    }
  }

  /* ================= PARTY ================= */

  static Future<List<dynamic>> getParties() async {
    final res = await http.get(Uri.parse("$baseUrl/parties"));
    if (res.statusCode != 200) {
      throw Exception("Failed to load parties");
    }
    return jsonDecode(res.body);
  }

  static Future<void> createParty({
    required String name,
    required String phone,
  }) async {
    final res = await http.post(
      Uri.parse("$baseUrl/parties"),
      headers: {"Content-Type": "application/json"},
      body: jsonEncode({"name": name, "phone": phone}),
    );

    if (res.statusCode != 200 && res.statusCode != 201) {
      throw Exception("Failed to create party");
    }
  }

  /* ================= YARN ================= */

  static Future<List<dynamic>> getPartyYarn() async {
    final res = await http.get(Uri.parse("$baseUrl/reports/party-yarn"));
    if (res.statusCode != 200) {
      throw Exception("Failed to load party yarn");
    }
    return jsonDecode(res.body);
  }

  static Future<void> addYarnInward({
    required int partyId,
    required int yarnId,
    required String lotNo,
    required double quantity,
    required int boxes,
    required String challanNo,
    required String inwardDate,
  }) async {
    final res = await http.post(
      Uri.parse("$baseUrl/yarn/inward"),
      headers: {"Content-Type": "application/json"},
      body: jsonEncode({
        "party_id": partyId,
        "yarn_id": yarnId,
        "lot_no": lotNo,
        "quantity": quantity,
        "boxes": boxes,
        "challan_no": challanNo,
        "inward_date": inwardDate,
      }),
    );

    if (res.statusCode != 200 && res.statusCode != 201) {
      throw Exception("Failed to add yarn inward");
    }
  }

  static Future<void> issueYarn({
    required int jobId,
    required int yarnStockId,
    required double quantity,
  }) async {
    final res = await http.post(
      Uri.parse("$baseUrl/yarn/issue"),
      headers: {"Content-Type": "application/json"},
      body: jsonEncode({
        "job_id": jobId,
        "yarn_stock_id": yarnStockId,
        "quantity": quantity,
      }),
    );

    if (res.statusCode != 200 && res.statusCode != 201) {
      throw Exception("Failed to issue yarn");
    }
  }

  /* ================= PRODUCTS ================= */

  static Future<List<dynamic>> getYarns() async {
    final res = await http.get(Uri.parse("$baseUrl/products/YARN"));
    if (res.statusCode != 200) {
      throw Exception("Failed to load yarns");
    }
    return jsonDecode(res.body);
  }

  static Future<List<dynamic>> getFabrics() async {
    final res = await http.get(Uri.parse("$baseUrl/products/FABRIC"));
    if (res.statusCode != 200) {
      throw Exception("Failed to load fabrics");
    }
    return jsonDecode(res.body);
  }

  static Future<void> addProduct({
    required String name,
    required String type,
  }) async {
    final res = await http.post(
      Uri.parse("$baseUrl/products"),
      headers: {"Content-Type": "application/json"},
      body: jsonEncode({"name": name, "type": type}),
    );

    if (res.statusCode != 200 && res.statusCode != 201) {
      throw Exception("Failed to add product");
    }
  }

  /* ================= MACHINES ================= */

  static Future<List<dynamic>> getMachines() async {
    final res = await http.get(Uri.parse("$baseUrl/machines"));
    if (res.statusCode != 200) {
      throw Exception("Failed to load machines");
    }
    return jsonDecode(res.body);
  }

  static Future<void> createMachine(String machineNo) async {
    final res = await http.post(
      Uri.parse("$baseUrl/machines"),
      headers: {"Content-Type": "application/json"},
      body: jsonEncode({"machine_no": machineNo}),
    );

    if (res.statusCode != 200 && res.statusCode != 201) {
      throw Exception("Failed to create machine");
    }
  }

  // ================= ADD PRODUCTION =================
  static Future<void> addProduction({
    required int jobId,
    required String rollNo,
    required double quantity,
  }) async {
    final res = await http.post(
      Uri.parse("$baseUrl/production"),
      headers: {"Content-Type": "application/json"},
      body: jsonEncode({
        "job_id": jobId,
        "roll_no": rollNo,
        "quantity": quantity,
      }),
    );

    if (res.statusCode != 200 && res.statusCode != 201) {
      throw Exception("Failed to add production");
    }
  }

  // ================= YARN RETURN =================
  static Future<void> returnYarn({
    required int jobId,
    required int partyId,
    required double quantity,
  }) async {
    final res = await http.post(
      Uri.parse("$baseUrl/yarn/return"),
      headers: {"Content-Type": "application/json"},
      body: jsonEncode({
        "job_id": jobId,
        "party_id": partyId,
        "quantity": quantity,
      }),
    );

    if (res.statusCode != 200) {
      throw Exception("Failed to return yarn");
    }
  }

  // ================= ADD WASTE =================
  static Future<void> addWaste({
    required int jobId,
    required double quantity,
  }) async {
    final res = await http.post(
      Uri.parse("$baseUrl/jobs/waste"),
      headers: {"Content-Type": "application/json"},
      body: jsonEncode({"job_id": jobId, "quantity": quantity}),
    );

    if (res.statusCode != 200) {
      throw Exception("Failed to add waste");
    }
  }
}
