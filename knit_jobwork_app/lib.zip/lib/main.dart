import 'package:flutter/material.dart';

import 'services/api_service.dart';
import 'screens/party_yarn_screen.dart';
import 'screens/create_job_screen.dart';
import 'screens/issue_yarn_screen.dart';
import 'screens/production_entry_screen.dart';
import 'screens/job_detail_screen.dart';
import 'screens/product_manager_screen.dart';
import 'screens/machine_screen.dart';

void main() {
  runApp(const KnitApp());
}

/* ================= APP ROOT ================= */

class KnitApp extends StatelessWidget {
  const KnitApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,

      theme: ThemeData(
        brightness: Brightness.dark,
        scaffoldBackgroundColor: const Color(0xFF121212),

        colorScheme: const ColorScheme.dark(primary: Color(0xFF00BFA6)),

        appBarTheme: const AppBarTheme(
          backgroundColor: Color(0xFF1E1E1E),
          elevation: 0,
          centerTitle: true,
        ),

        cardTheme: const CardThemeData(
          color: Color(0xFF1E1E1E),
          elevation: 3,
          shape: RoundedRectangleBorder(
            borderRadius: BorderRadius.all(Radius.circular(16)),
          ),
        ),

        floatingActionButtonTheme: const FloatingActionButtonThemeData(
          backgroundColor: Color(0xFF00BFA6),
          foregroundColor: Colors.black,
        ),

        bottomNavigationBarTheme: const BottomNavigationBarThemeData(
          backgroundColor: Color(0xFF1E1E1E),
          selectedItemColor: Color(0xFF00BFA6),
          unselectedItemColor: Colors.grey,
          type: BottomNavigationBarType.fixed,
        ),
      ),

      home: const Dashboard(),
    );
  }
}

/* ================= DASHBOARD ================= */

class Dashboard extends StatefulWidget {
  const Dashboard({super.key});

  @override
  State<Dashboard> createState() => _DashboardState();
}

class _DashboardState extends State<Dashboard> {
  int _index = 0;

  final List<Widget> screens = const [
    JobReportScreen(),
    PartyYarnScreen(),
    MachineScreen(),
    ProductManagerScreen(),
  ];

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: screens[_index],
      bottomNavigationBar: BottomNavigationBar(
        currentIndex: _index,
        onTap: (i) => setState(() => _index = i),
        items: const [
          BottomNavigationBarItem(icon: Icon(Icons.factory), label: "Jobs"),
          BottomNavigationBarItem(icon: Icon(Icons.inventory), label: "Yarn"),
          BottomNavigationBarItem(
            icon: Icon(Icons.precision_manufacturing),
            label: "Machines",
          ),
          BottomNavigationBarItem(
            icon: Icon(Icons.category),
            label: "Products",
          ),
        ],
      ),
    );
  }
}

/* ================= JOB SUMMARY SCREEN ================= */

class JobReportScreen extends StatefulWidget {
  const JobReportScreen({super.key});

  @override
  State<JobReportScreen> createState() => _JobReportScreenState();
}

class _JobReportScreenState extends State<JobReportScreen> {
  Color statusColor(String status) {
    switch (status) {
      case 'RUNNING':
        return Colors.green;
      case 'STOPPED':
        return Colors.red;
      case 'COMPLETED':
        return Colors.blue;
      default:
        return Colors.orange;
    }
  }

  Widget summaryBox(String title, double value, Color color) {
    return Expanded(
      child: Container(
        margin: const EdgeInsets.symmetric(horizontal: 4),
        padding: const EdgeInsets.all(10),
        decoration: BoxDecoration(
          color: color.withOpacity(0.15),
          borderRadius: BorderRadius.circular(12),
        ),
        child: Column(
          children: [
            Text(title, style: TextStyle(fontSize: 12, color: color)),
            const SizedBox(height: 4),
            Text(
              value.toStringAsFixed(1),
              style: TextStyle(
                fontSize: 15,
                fontWeight: FontWeight.bold,
                color: color,
              ),
            ),
          ],
        ),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text("Job Summary")),

      floatingActionButton: FloatingActionButton(
        tooltip: "Create Job",
        onPressed: () {
          Navigator.push(
            context,
            MaterialPageRoute(builder: (_) => const CreateJobScreen()),
          );
        },
        child: const Icon(Icons.add),
      ),

      body: FutureBuilder<List<dynamic>>(
        future: ApiService.getJobs(),
        builder: (context, snapshot) {
          if (snapshot.connectionState == ConnectionState.waiting) {
            return const Center(child: CircularProgressIndicator());
          }

          if (snapshot.hasError) {
            return Center(child: Text("Error: ${snapshot.error}"));
          }

          final jobs = snapshot.data ?? [];

          if (jobs.isEmpty) {
            return const Center(child: Text("No jobs created yet"));
          }

          return RefreshIndicator(
            onRefresh: () async => setState(() {}),
            child: ListView.builder(
              padding: const EdgeInsets.only(bottom: 80),
              itemCount: jobs.length,
              itemBuilder: (context, index) {
                final j = jobs[index];

                final int? jobId = j['job_id'];
                final String? jobNo = j['job_no'];

                final double orderQty =
                    double.tryParse(j['order_quantity'].toString()) ?? 0;
                final double production =
                    double.tryParse(j['production_qty'].toString()) ?? 0;

                final double productionLeft = orderQty - production;

                return Card(
                  margin: const EdgeInsets.symmetric(
                    horizontal: 12,
                    vertical: 8,
                  ),
                  child: InkWell(
                    borderRadius: BorderRadius.circular(16),
                    onTap: jobId == null
                        ? null
                        : () {
                            Navigator.push(
                              context,
                              MaterialPageRoute(
                                builder: (_) => JobDetailScreen(
                                  jobId: jobId,
                                  jobNo: jobNo ?? '',
                                ),
                              ),
                            );
                          },
                    child: Padding(
                      padding: const EdgeInsets.all(14),
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          /// HEADER
                          Row(
                            mainAxisAlignment: MainAxisAlignment.spaceBetween,
                            children: [
                              Text(
                                "Job ${jobNo ?? '-'}",
                                style: const TextStyle(
                                  fontSize: 16,
                                  fontWeight: FontWeight.bold,
                                ),
                              ),
                              Container(
                                padding: const EdgeInsets.symmetric(
                                  horizontal: 10,
                                  vertical: 4,
                                ),
                                decoration: BoxDecoration(
                                  color: statusColor(j['status'] ?? 'OPEN'),
                                  borderRadius: BorderRadius.circular(20),
                                ),
                                child: Text(
                                  j['status'] ?? 'OPEN',
                                  style: const TextStyle(
                                    color: Colors.white,
                                    fontSize: 12,
                                  ),
                                ),
                              ),
                            ],
                          ),

                          const SizedBox(height: 6),

                          Text(
                            "${j['party_name'] ?? '-'}",
                            style: const TextStyle(color: Colors.grey),
                          ),

                          const SizedBox(height: 12),

                          /// SUMMARY
                          Row(
                            children: [
                              summaryBox("Order", orderQty, Colors.blue),
                              summaryBox("Produced", production, Colors.green),
                              summaryBox(
                                "Left",
                                productionLeft,
                                productionLeft <= 0
                                    ? Colors.green
                                    : Colors.orange,
                              ),
                            ],
                          ),

                          const SizedBox(height: 12),

                          /// ACTION BUTTONS
                          Row(
                            children: [
                              Expanded(
                                child: ElevatedButton.icon(
                                  style: ElevatedButton.styleFrom(
                                    backgroundColor: const Color(0xFF00BFA6),
                                    foregroundColor: Colors.black, // 👈 FIXED
                                  ),
                                  icon: const Icon(Icons.send),
                                  label: const Text(
                                    "Issue Yarn",
                                    style: TextStyle(
                                      fontWeight: FontWeight.bold,
                                    ),
                                  ),
                                  onPressed: jobId == null
                                      ? null
                                      : () {
                                          Navigator.push(
                                            context,
                                            MaterialPageRoute(
                                              builder: (_) =>
                                                  IssueYarnScreen(jobId: jobId),
                                            ),
                                          );
                                        },
                                ),
                              ),
                              const SizedBox(width: 10),
                              Expanded(
                                child: ElevatedButton.icon(
                                  style: ElevatedButton.styleFrom(
                                    backgroundColor: Colors.deepPurple,
                                  ),
                                  icon: const Icon(Icons.add),
                                  label: const Text("Production"),
                                  onPressed: jobId == null
                                      ? null
                                      : () {
                                          Navigator.push(
                                            context,
                                            MaterialPageRoute(
                                              builder: (_) =>
                                                  ProductionEntryScreen(
                                                    jobId: jobId,
                                                  ),
                                            ),
                                          );
                                        },
                                ),
                              ),
                            ],
                          ),
                        ],
                      ),
                    ),
                  ),
                );
              },
            ),
          );
        },
      ),
    );
  }
}
