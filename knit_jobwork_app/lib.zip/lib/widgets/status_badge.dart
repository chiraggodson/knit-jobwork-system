import 'package:flutter/material.dart';
import '../theme/app_colors.dart';
import '../models/machine_model.dart';

class StatusBadge extends StatelessWidget {
  final MachineStatus status;

  const StatusBadge({super.key, required this.status});

  @override
  Widget build(BuildContext context) {
    late Color color;
    late String label;

    switch (status) {
      case MachineStatus.running:
        color = AppColors.green;
        label = "RUNNING";
        break;
      case MachineStatus.cleaning:
        color = AppColors.yellow;
        label = "CLEANING";
        break;
      case MachineStatus.sampling:
        color = AppColors.blue;
        label = "SAMPLING";
        break;
      case MachineStatus.stopped:
        color = AppColors.red;
        label = "STOPPED";
        break;
      case MachineStatus.idle:
        color = AppColors.textMuted;
        label = "IDLE";
        break;
    }

    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 4),
      decoration: BoxDecoration(
        color: color.withOpacity(0.15),
        borderRadius: BorderRadius.circular(12),
      ),
      child: Text(
        label,
        style: TextStyle(
          fontSize: 10,
          fontWeight: FontWeight.w600,
          color: color,
        ),
      ),
    );
  }
}
