import 'package:flutter/material.dart';
import '../theme/app_colors.dart';

class MachineStatusCardApi extends StatelessWidget {
  final Map machine;
  final bool isAdmin;

  const MachineStatusCardApi({
    super.key,
    required this.machine,
    required this.isAdmin,
  });

  Color _statusColor(String status) {
    switch (status) {
      case "RUNNING":
        return AppColors.green;
      case "CLEANING":
        return AppColors.yellow;
      case "SAMPLING":
        return AppColors.blue;
      case "BREAKDOWN":
        return AppColors.red;
      default:
        return AppColors.textMuted;
    }
  }

  @override
  Widget build(BuildContext context) {
    final status = machine['status'] ?? "IDLE";

    return Container(
      width: 240,
      padding: const EdgeInsets.all(14),
      decoration: BoxDecoration(
        color: AppColors.card,
        borderRadius: BorderRadius.circular(14),
        boxShadow: [
          BoxShadow(
            color: Colors.black.withOpacity(0.05),
            blurRadius: 10,
          )
        ],
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          // Header
          Row(
            children: [
              Text(
                "Machine ${machine['machine_no']}",
                style: const TextStyle(
                  fontWeight: FontWeight.w600,
                  fontSize: 14,
                ),
              ),
              const Spacer(),
              Container(
                padding:
                    const EdgeInsets.symmetric(horizontal: 8, vertical: 4),
                decoration: BoxDecoration(
                  color: _statusColor(status).withOpacity(0.15),
                  borderRadius: BorderRadius.circular(12),
                ),
                child: Text(
                  status,
                  style: TextStyle(
                    fontSize: 10,
                    fontWeight: FontWeight.w600,
                    color: _statusColor(status),
                  ),
                ),
              ),
            ],
          ),

          const SizedBox(height: 12),

          Text(
            machine['job_no'] ?? "No Active Job",
            style: TextStyle(
              fontSize: 13,
              color: AppColors.textPrimary,
              fontWeight: FontWeight.w500,
            ),
          ),

          const Spacer(),

          if (isAdmin)
            Align(
              alignment: Alignment.bottomRight,
              child: Icon(
                Icons.edit,
                size: 18,
                color: AppColors.textMuted,
              ),
            )
        ],
      ),
    );
  }
}
