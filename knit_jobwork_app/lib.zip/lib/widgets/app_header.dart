import 'package:flutter/material.dart';
import '../theme/app_colors.dart';
import '../models/user_model.dart';

class AppHeader extends StatelessWidget {
  final String title;
  final String subtitle;
  final UserModel user;

  const AppHeader({
    super.key,
    required this.title,
    required this.subtitle,
    required this.user,
  });

  @override
  Widget build(BuildContext context) {
    return Container(
      height: 78,
      padding: const EdgeInsets.symmetric(horizontal: 20),
      color: AppColors.header,
      child: Row(
        children: [
          Column(
            mainAxisAlignment: MainAxisAlignment.center,
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text(title,
                  style: const TextStyle(
                      color: Colors.white,
                      fontSize: 18,
                      fontWeight: FontWeight.w600)),
              const SizedBox(height: 4),
              Text(subtitle,
                  style: TextStyle(
                      color: Colors.white.withOpacity(0.7),
                      fontSize: 12)),
            ],
          ),
          const Spacer(),
          Column(
            mainAxisAlignment: MainAxisAlignment.center,
            crossAxisAlignment: CrossAxisAlignment.end,
            children: [
              Text(user.name,
                  style: const TextStyle(
                      color: Colors.white,
                      fontWeight: FontWeight.w500)),
              const SizedBox(height: 2),
              Container(
                padding:
                    const EdgeInsets.symmetric(horizontal: 8, vertical: 2),
                decoration: BoxDecoration(
                  color: user.isAdmin
                      ? AppColors.red
                      : Colors.white.withOpacity(0.2),
                  borderRadius: BorderRadius.circular(12),
                ),
                child: Text(
                  user.isAdmin ? "ADMIN" : "USER",
                  style: const TextStyle(
                      color: Colors.white, fontSize: 10),
                ),
              )
            ],
          )
        ],
      ),
    );
  }
}
