import 'package:flutter/material.dart';
import '../models/machine_model.dart';
import '../theme/app_colors.dart';
import 'status_badge.dart';

class MachineStatusCard extends StatelessWidget {
  final MachineModel machine;
  final bool isAdmin;

  const MachineStatusCard({
    super.key,
    required this.machine,
    required this.isAdmin,
  });

  @override
  Widget build(BuildContext context) {
    return Container(
      width: 240,
      padding: const EdgeInsets.all(14),
      decoration: BoxDecoration(
        color: AppColors.card,
        borderRadius: BorderRadius.circular(14),
        boxShadow: [
          BoxShadow(
            color: Colors.black.withOpacity(0.05),
            blurRadius: 10,
          )
        ],
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          // Header row
          Row(
            children: [
              Text(
                "Machine ${machine.machineNo}",
                style: const TextStyle(
                  fontWeight: FontWeight.w600,
                  fontSize: 14,
                ),
              ),
              const Spacer(),
              StatusBadge(status: machine.status),
            ],
          ),

          const SizedBox(height: 12),

          // Job info
          Text(
            machine.jobName ?? "No Active Job",
            style: TextStyle(
              fontSize: 13,
              color: AppColors.textPrimary,
              fontWeight: FontWeight.w500,
            ),
          ),

          if (machine.fabric != null) ...[
            const SizedBox(height: 4),
            Text(
              machine.fabric!,
              style: TextStyle(
                fontSize: 12,
                color: AppColors.textMuted,
              ),
            ),
          ],

          const Spacer(),

          // Admin action
          if (isAdmin)
            Align(
              alignment: Alignment.bottomRight,
              child: Icon(
                Icons.edit,
                size: 18,
                color: AppColors.textMuted,
              ),
            )
        ],
      ),
    );
  }
}
