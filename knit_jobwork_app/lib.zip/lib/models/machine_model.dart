enum MachineStatus {
  running,
  cleaning,
  sampling,
  stopped,
  idle,
}

class MachineModel {
  final String machineNo;
  final MachineStatus status;
  final String? jobName;
  final String? fabric;

  MachineModel({
    required this.machineNo,
    required this.status,
    this.jobName,
    this.fabric,
  });
}
