import express from "express";
import { pool } from "../db.js";

const router = express.Router();

/**
 * ADD YARN INWARD (Party Yarn Stock)
 */
router.post("/stock", async (req, res) => {
  try {
    const {
      party_id,
      yarn_id,
      lot_no,
      quantity,
      boxes,
      challan_no,
      inward_date,
    } = req.body;

    if (!party_id || !yarn_id || !lot_no || !quantity) {
      return res.status(400).json({ error: "Missing required fields" });
    }

    const result = await pool.query(
      `
      INSERT INTO yarn_stock
      (party_id, yarn_id, lot_no, quantity, boxes, challan_no, inward_date)
      VALUES ($1,$2,$3,$4,$5,$6,$7)
      RETURNING *
      `,
      [party_id, yarn_id, lot_no, quantity, boxes || 0, challan_no || null, inward_date || new Date()]
    );

    res.status(201).json(result.rows[0]);
  } catch (err) {
    console.error("❌ Yarn inward error:", err);
    res.status(500).json({ error: "Failed to add yarn stock" });
  }
});


/**
 * VIEW YARN STOCK (Party-wise)
 */
router.get("/stock", async (req, res) => {
  const result = await pool.query(
    `SELECT y.*, p.name AS party_name
     FROM yarn_stock y
     JOIN parties p ON p.id = y.party_id
     ORDER BY y.id DESC`
  );
  res.json(result.rows);
});


/**
 * ISSUE YARN TO JOB
 */
router.post("/issue", async (req, res) => {
  try {
    const { job_id, yarn_stock_id, quantity } = req.body;

    if (!job_id || !yarn_stock_id || !quantity || quantity <= 0) {
      return res.status(400).json({ error: "Invalid input" });
    }

    // 🔍 check available balance
    const stock = await pool.query(
      `
      SELECT
        ys.quantity - COALESCE(SUM(yi.quantity),0) AS balance
      FROM yarn_stock ys
      LEFT JOIN yarn_issue yi ON yi.yarn_stock_id = ys.id
      WHERE ys.id = $1
      GROUP BY ys.quantity
      `,
      [yarn_stock_id]
    );

    if (stock.rowCount === 0) {
      return res.status(400).json({ error: "Invalid yarn stock" });
    }

    if (stock.rows[0].balance < quantity) {
      return res.status(400).json({ error: "Insufficient yarn balance" });
    }

    // ✅ record issue ONLY
    await pool.query(
      `
      INSERT INTO yarn_issue (job_id, yarn_stock_id, quantity)
      VALUES ($1,$2,$3)
      `,
      [job_id, yarn_stock_id, quantity]
    );

    // ✅ update job summary
    await pool.query(
      `
      UPDATE job_orders
      SET yarn_issued = yarn_issued + $1
      WHERE id = $2
      `,
      [quantity, job_id]
    );

    res.json({ message: "Yarn issued successfully" });
  } catch (err) {
    console.error("❌ Yarn issue error:", err);
    res.status(500).json({ error: "Yarn issue failed" });
  }
});


router.post("/return", async (req, res) => {
  try {
    const { job_id, returned_qty, waste_qty } = req.body || {};

    if (!job_id) {
      return res.status(400).json({ error: "job_id required" });
    }

    // check job exists and open
    const job = await pool.query(
      "SELECT status FROM job_orders WHERE id = $1",
      [job_id]
    );

    if (job.rowCount === 0) {
      return res.status(400).json({ error: "Invalid job_id" });
    }

    if (job.rows[0].status === "CLOSED") {
      return res.status(400).json({ error: "Job already closed" });
    }

    // insert yarn return
    await pool.query(
      `INSERT INTO yarn_return (job_id, returned_qty, waste_qty)
       VALUES ($1,$2,$3)`,
      [job_id, returned_qty || 0, waste_qty || 0]
    );

    // update job order
    await pool.query(
      `UPDATE job_orders
       SET yarn_returned = $1,
           waste = $2,
           status = 'CLOSED'
       WHERE id = $3`,
      [returned_qty || 0, waste_qty || 0, job_id]
    );

    res.json({ message: "Job closed successfully" });
  } catch (err) {
    console.error(err);
    res.status(500).json({ error: "Job close failed" });
  }
});

router.delete("/inward/:id", async (req, res) => {
  try {
    const { id } = req.params;

    // Check if yarn was issued
    const issued = await pool.query(
      `SELECT COUNT(*) FROM yarn_issue WHERE yarn_stock_id = $1`,
      [id]
    );

    if (issued.rows[0].count > 0) {
      return res.status(400).json({
        error: "Cannot delete. Yarn already issued from this inward entry.",
      });
    }

    await pool.query(`DELETE FROM yarn_stock WHERE id = $1`, [id]);

    res.json({ message: "Yarn inward deleted" });
  } catch (err) {
    console.error(err);
    res.status(500).json({ error: "Delete failed" });
  }
});
router.post("/inward", async (req, res) => {
  const {
    party_id,
    yarn_id,
    lot_no,
    quantity,
    boxes,
    challan_no,
    inward_date,
  } = req.body;

  if (!party_id || !yarn_id || !lot_no || !quantity) {
    return res.status(400).json({ error: "Missing fields" });
  }

  const result = await pool.query(
    `
    INSERT INTO yarn_stock
    (party_id, yarn_id, lot_no, quantity, boxes, challan_no, inward_date)
    VALUES ($1,$2,$3,$4,$5,$6,$7)
    RETURNING *
    `,
    [party_id, yarn_id, lot_no, quantity, boxes, challan_no, inward_date]
  );

  res.json(result.rows[0]);
});
// ================= YARN RETURN (JOB → PARTY) =================
router.post("/return", async (req, res) => {
  const { job_id, party_id, quantity } = req.body;

  if (!job_id || !party_id || !quantity) {
    return res.status(400).json({ error: "Missing fields" });
  }

  try {
    await pool.query("BEGIN");

    // 1️⃣ Update job yarn_returned
    await pool.query(
      `
      UPDATE job_orders
      SET yarn_returned = COALESCE(yarn_returned, 0) + $1
      WHERE id = $2
      `,
      [quantity, job_id]
    );

    // 2️⃣ Add yarn back to party yarn (simple version)
    await pool.query(
      `
      UPDATE party_yarn
      SET quantity = quantity + $1
      WHERE party_id = $2
      `,
      [quantity, party_id]
    );

    await pool.query("COMMIT");

    res.json({ message: "Yarn returned successfully" });
  } catch (err) {
    await pool.query("ROLLBACK");
    console.error("❌ YARN RETURN ERROR:", err);
    res.status(500).json({ error: "Failed to return yarn" });
  }
});

  // ================= ADD WASTE =================
router.post("/waste", async (req, res) => {
  try {
    const { job_id, quantity } = req.body;

    if (!job_id || !quantity) {
      return res.status(400).json({ error: "Missing fields" });
    }

    await pool.query(
      `
      UPDATE job_orders
      SET waste = COALESCE(waste,0) + $1
      WHERE id = $2
      `,
      [quantity, job_id]
    );

    res.json({ message: "Waste recorded successfully" });
  } catch (err) {
    console.error("❌ WASTE ERROR:", err);
    res.status(500).json({ error: "Failed to add waste" });
  }
});





export default router;
