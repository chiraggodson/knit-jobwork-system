import express from "express";
import { pool } from "../db.js";

const router = express.Router();

/* ===== job detail route ===== */
router.get("/job/:jobNo", async (req, res) => {
  const { jobNo } = req.params;

  try {
    const result = await pool.query(
      `
      SELECT
      j.id AS job_id,
        j.job_no,
        j.fabric_type,
        j.party_id,
        j.gsm,
        j.order_quantity,
        j.yarn_issued,
        j.fabric_produced,
        j.yarn_returned,
        j.waste,
        j.status,
        j.created_at,
        p.name AS party_name,
        m.machine_no
      FROM job_orders j
      LEFT JOIN parties p ON p.id = j.party_id
      LEFT JOIN machines m ON m.id = j.machine_id
      WHERE j.job_no = $1
      `,
      [jobNo]
    );

    if (result.rowCount === 0) {
      return res.status(404).json({ error: "Job not found" });
    }

    res.json(result.rows[0]);
  } catch (err) {
    console.error("❌ JOB DETAIL ERROR:", err);
    res.status(500).json({ error: "Failed to load job detail" });
  }
});

/* ===== other report routes here ===== */
/* ===== JOB SUMMARY LIST ===== */
router.get("/jobs", async (req, res) => {
  try {
    const result = await pool.query(`
      SELECT
        j.id AS job_id,
        j.job_no,
        j.fabric_type,
        j.gsm,
        j.order_quantity,
        j.yarn_issued,
        j.fabric_produced,
        j.status,
        j.created_at,
        p.name AS party_name,
        m.machine_no
      FROM job_orders j
      LEFT JOIN parties p ON p.id = j.party_id
      LEFT JOIN machines m ON m.id = j.machine_id
      ORDER BY j.created_at DESC
    `);

    res.json(result.rows);
  } catch (err) {
    console.error("❌ JOB LIST ERROR:", err);
    res.status(500).json({ error: "Failed to load jobs" });
  }
});

/* ===== PARTY YARN LEDGER ===== */
router.get("/party-yarn", async (req, res) => {
  try {
    const result = await pool.query(`
      SELECT
        p.id AS party_id,
        p.name AS party_name,
        COALESCE(SUM(ys.quantity), 0) AS yarn_inward,
        COALESCE(SUM(yi.quantity), 0) AS yarn_issued,
        COALESCE(SUM(ys.quantity), 0) - COALESCE(SUM(yi.quantity), 0) AS balance
      FROM parties p
      LEFT JOIN yarn_stock ys ON ys.party_id = p.id
      LEFT JOIN yarn_issue yi ON yi.yarn_stock_id = ys.id
      GROUP BY p.id, p.name
      ORDER BY p.name
    `);

    res.json(result.rows);
  } catch (err) {
    console.error("❌ PARTY YARN ERROR:", err);
    res.status(500).json({ error: "Failed to load party yarn" });
  }
});


export default router; // ✅ THIS LINE IS MANDATORY
