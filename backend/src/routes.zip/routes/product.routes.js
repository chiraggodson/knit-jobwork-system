import express from "express";
import { pool } from "../db.js";

const router = express.Router();

/* ADD PRODUCT */
router.post("/", async (req, res) => {
  const { name, type } = req.body;

  if (!name || !type) {
    return res.status(400).json({ error: "Name & type required" });
  }

  const result = await pool.query(
    `INSERT INTO products (name, type)
     VALUES ($1, $2)
     RETURNING *`,
    [name, type]
  );

  res.json(result.rows[0]);
});

/* GET BY TYPE */
router.get("/:type", async (req, res) => {
  const { type } = req.params;

  const result = await pool.query(
    `SELECT id, name FROM products WHERE type=$1 ORDER BY name`,
    [type.toUpperCase()]
  );

  res.json(result.rows);
});

export default router;
