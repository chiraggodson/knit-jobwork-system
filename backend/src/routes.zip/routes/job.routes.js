console.log("✅ job.routes.js LOADED");

import express from "express";
import { pool } from "../db.js";

const router = express.Router();

/* ================= CREATE JOB ================= */
router.post("/", async (req, res) => {
  console.log("🔥 CREATE JOB ROUTE HIT");
  console.log("REQ BODY:", req.body);

  try {
    const {
      party_id,
      machine_id,
      fabric_type,
      gsm,
      order_quantity,
    } = req.body;

    if (
      !party_id ||
      !machine_id ||
      !fabric_type ||
      !gsm ||
      !order_quantity
    ) {
      return res.status(400).json({
        error:
          "party_id, machine_id, fabric_type, gsm, order_quantity required",
      });
    }

    // 1️⃣ Insert job
    const result = await pool.query(
      `
      INSERT INTO job_orders
        (party_id, machine_id, fabric_type, gsm, order_quantity, status)
      VALUES
        ($1, $2, $3, $4, $5, 'OPEN')
      RETURNING *
      `,
      [party_id, machine_id, fabric_type, gsm, order_quantity]
    );

    // 2️⃣ Generate job_no
    const jobId = result.rows[0].id;
    const jobNo = "BBJO" + String(jobId).padStart(3, "0");

    await pool.query(
      `UPDATE job_orders SET job_no = $1 WHERE id = $2`,
      [jobNo, jobId]
    );

    res.status(201).json({
      ...result.rows[0],
      job_no: jobNo,
    });
  } catch (err) {
    console.error("❌ CREATE JOB ERROR:", err);
    res.status(500).json({
      message: err.message,
      detail: err.detail,
      code: err.code,
    });
  }
});

/* ================= JOB LIST ================= */
router.get("/", async (req, res) => {
  try {
    const result = await pool.query(`
      SELECT
        j.id,
        j.job_no,
        j.fabric_type,
        j.gsm,
        j.order_quantity,
        j.yarn_issued,
        j.fabric_produced,
        j.status,
        j.created_at,
        p.name AS party_name,
        m.machine_no
      FROM job_orders j
      LEFT JOIN parties p ON p.id = j.party_id
      LEFT JOIN machines m ON m.id = j.machine_id
      ORDER BY j.created_at DESC
    `);

    res.json(result.rows);
  } catch (err) {
    console.error("❌ GET JOBS ERROR:", err);
    res.status(500).json({ error: "Failed to load jobs" });
  }
});

/* ================= SINGLE JOB DETAIL ================= */
router.get("/:job_no", async (req, res) => {
  try {
    const { job_no } = req.params;

    const result = await pool.query(
      `
      SELECT
        j.id,
        j.job_no,
        j.fabric_type,
        j.gsm,
        j.order_quantity,
        j.yarn_issued,
        j.fabric_produced,
        j.yarn_returned,
        j.waste,
        j.status,
        p.name AS party_name,
        m.machine_no
      FROM job_orders j
      LEFT JOIN parties p ON p.id = j.party_id
      LEFT JOIN machines m ON m.id = j.machine_id
      WHERE j.job_no = $1
      `,
      [job_no]
    );

    if (result.rowCount === 0) {
      return res.status(404).json({ error: "Job not found" });
    }

    res.json(result.rows[0]);
  } catch (err) {
    console.error("❌ JOB DETAIL ERROR:", err);
    res.status(500).json({ error: "Failed to load job detail" });
  }
});

/* ================= CLOSE JOB ================= */
router.put("/close/:job_no", async (req, res) => {
  try {
    const { job_no } = req.params;

    const result = await pool.query(
      `
      UPDATE job_orders
      SET status = 'CLOSED'
      WHERE job_no = $1
      RETURNING *
      `,
      [job_no]
    );

    if (result.rowCount === 0) {
      return res.status(404).json({ error: "Job not found" });
    }

    res.json(result.rows[0]);
  } catch (err) {
    console.error("❌ CLOSE JOB ERROR:", err);
    res.status(500).json({ error: "Failed to close job" });
  }
});

export default router;
