import express from "express";
import { pool } from "../db.js";

const router = express.Router();

/* ================= CREATE MACHINE ================= */
router.post("/", async (req, res) => {
  try {
    const { machine_no } = req.body;

    if (!machine_no) {
      return res.status(400).json({ error: "machine_no required" });
    }

    const result = await pool.query(
      `INSERT INTO machines (machine_no)
       VALUES ($1)
       RETURNING *`,
      [machine_no]
    );

    res.status(201).json(result.rows[0]);
  } catch (err) {
    console.error("CREATE MACHINE ERROR:", err.message);
    res.status(500).json({ error: err.message });
  }
});

/* ================= GET ALL MACHINES ================= */
router.get("/", async (req, res) => {
  try {
    const result = await pool.query(`
      SELECT
        m.id,
        m.machine_no,
        m.status,
        j.job_no
      FROM machines m
      LEFT JOIN job_orders j ON j.machine_id = m.id AND j.status = 'OPEN'
      ORDER BY m.machine_no
    `);

    res.json(result.rows);
  } catch (err) {
    console.error("GET MACHINES ERROR:", err.message);
    res.status(500).json({ error: err.message });
  }
});

/* ================= UPDATE MACHINE STATUS ================= */
router.put("/:id/status", async (req, res) => {
  try {
    const { id } = req.params;
    const { status } = req.body;

    const result = await pool.query(
      `UPDATE machines SET status=$1 WHERE id=$2 RETURNING *`,
      [status, id]
    );

    res.json(result.rows[0]);
  } catch (err) {
    console.error("UPDATE MACHINE ERROR:", err.message);
    res.status(500).json({ error: err.message });
  }
});

export default router;
