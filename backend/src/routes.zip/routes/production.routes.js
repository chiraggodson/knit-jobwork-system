import express from "express";
import { pool } from "../db.js";

const router = express.Router();

/**
 * ADD FABRIC PRODUCTION (ROLL-WISE)
 */
router.post("/", async (req, res) => {
  try {
    const { job_id, roll_no, quantity } = req.body || {};

    if (!job_id || !quantity) {
      return res.status(400).json({ error: "job_id and quantity required" });
    }

    // insert roll
    await pool.query(
      `INSERT INTO fabric_production (job_id, roll_no, quantity)
       VALUES ($1,$2,$3)`,
      [job_id, roll_no, quantity]
    );

    // update job total fabric
    await pool.query(
      `UPDATE job_orders
       SET fabric_produced = fabric_produced + $1
       WHERE id = $2`,
      [quantity, job_id]
    );

    res.json({ message: "Production added successfully" });
  } catch (err) {
    console.error(err);
    res.status(500).json({ error: "Production entry failed" });
  }
});

/**
 * VIEW PRODUCTION (JOB-WISE)
 */
router.get("/:job_id", async (req, res) => {
  const { job_id } = req.params;

  const result = await pool.query(
    `SELECT * FROM fabric_production
     WHERE job_id = $1
     ORDER BY produced_at`,
    [job_id]
  );

  res.json(result.rows);
});

export default router;
